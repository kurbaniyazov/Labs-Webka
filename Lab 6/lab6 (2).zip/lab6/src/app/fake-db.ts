import {Albums} from "./modules";
export const ALBUMS: Albums[] = [
  {id: 1, title: 'title 1', body: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.'},
  {id: 2, title: 'title 2', body: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.'},
  {id: 3, title: 'title 3', body: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.'},
  {id: 4, title: 'title 4', body: 'Lorem ipsum dolor sit amet, consectetur adipisicing elit.'}
];
